click on the edamone.exe to run and access the  text editor
